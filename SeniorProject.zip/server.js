const http = require('http');
const { Pool } = require('pg');
const fs = require('fs');
const url = require('url');
const queryString = require('querystring');

// PostgreSQL connection setup
const pool = new Pool({
  // Replace with your database connection details
  user: 'postgres',
  host: 'localhost',
  database: 'postgres',
  password: '',
  port: 5432,
});
const sendFile = (res, filePath, contentType) => {
  fs.readFile(filePath, (err, data) => {
      if (err) {
          res.writeHead(500);
          return res.end('Error loading file');
      }
      res.writeHead(200, {'Content-Type': contentType});
      res.end(data);
  });
};
const isLoggedIn = (req) => {
  const cookies = req.headers.cookie;
  return cookies && cookies.includes('loggedIn=true');
};
const serveStaticFile = (res, path, contentType, responseCode = 200) => {
  fs.readFile(__dirname + path, (err, data) => {
    if (err) {
      res.writeHead(500);
      return res.end('Error loading file');
    }
    res.writeHead(responseCode, {'Content-Type': contentType});
    res.end(data);
  });
};
const server = http.createServer(async (req, res) => {
  console.log('Received request for URL:', req.url);
  const reqUrl = url.parse(req.url, true);
  //serve login page
  if (req.url === '/login.html') {
      sendFile(res, 'login.html', 'text/html');
      return;
  }
  // Serve register page
  if (req.url === '/register.html') {
      sendFile(res, 'register.html', 'text/html');
      return;
  }
  //serve account page
  if (req.url === '/userpage.html') {
    sendFile(res, 'userpage.html', 'text/html');
    return;
  }
  //serve homepage
  if (req.url === '/index.html') {
    sendFile(res, 'index.html', 'text/html');
    return;
  }
  // Handle login
  if (req.method === 'POST' && req.url === '/login') {
      let body = '';
      req.on('data', chunk => {
          body += chunk.toString(); // Convert Buffer to string
      });
      req.on('end', async () => {
          const { username, password } = JSON.parse(body); // extract username and password

          try {
              // Query your database to validate the username and password
              const result = await pool.query('SELECT * FROM profiles WHERE username = $1 AND password = $2', [username, password]);

              if (result.rows.length > 0) {
                  // If credentials are valid
                  res.setHeader('Set-Cookie', 'loggedIn=true; HttpOnly; Path=/;');
                  res.writeHead(200, {'Content-Type': 'application/json'});
                  res.end(JSON.stringify({ message: 'Login successful', username }));
              } else {
                  // If credentials are invalid
                  res.writeHead(401, {'Content-Type': 'application/json'}); // 401 Unauthorized
                  res.end(JSON.stringify({ message: 'Login failed' }));
              }
          } catch (error) {
              // Handle any errors that occur during the process
              console.error('Login error:', error);
              res.writeHead(500, {'Content-Type': 'application/json'}); // 500 Internal Server Error
              res.end(JSON.stringify({ message: 'Internal server error' }));
          }
      });
  }
  // Handle logout
  if (req.url === '/logout') {
      res.setHeader('Set-Cookie', 'loggedIn=; HttpOnly; Path=/; Max-Age=0;');
      res.writeHead(302, { 'Location': '/login.html' });
      res.end();
      return;
  }
  // Handle registration
  if (req.method === 'POST' && req.url === '/register') {
      let body = '';
      req.on('data', chunk => {
          body += chunk.toString();
      });

      req.on('end', async () => {
          const { fullname, username, password } = JSON.parse(body);
          try {
              // Insert user into database
              await pool.query('INSERT INTO profiles (fullname, username, password) VALUES ($1, $2, $3)', [fullname, username, password]);
              await pool.query(
                'INSERT INTO user_relationships (follower_username, following_username) VALUES ($1, $2)',
                [username, username]
              );
              res.writeHead(200, {'Content-Type': 'application/json'});
              res.end(JSON.stringify({ message: 'User registered successfully' }));
          } catch (error) {
              if (error.code === '23505') { // Unique constraint violation
                  res.writeHead(400, {'Content-Type': 'application/json'}); // Bad Request
                  res.end(JSON.stringify({ message: 'Username already taken' }));
              } else {
                  // Handle other errors
                  console.error('Error:', error);
                  res.writeHead(500);
                  res.end(JSON.stringify({ message: 'Registration failed' }));
              }
          }
      });
  }
  // Restrict access to index.html
  if (req.url === '/') {
      if (!isLoggedIn(req)) {
          res.writeHead(302, { 'Location': '/login.html' });
          res.end();
          return;
      }
      sendFile(res, 'index.html', 'text/html');
      return;
  }
  //fetch form images folder
  if (req.method === 'GET' && reqUrl.pathname.startsWith('/images/')) {
    const path = reqUrl.pathname;
    let contentType = 'text/plain';

    if (path.endsWith('.png')) {
      contentType = 'image/png';
    } else if (path.endsWith('.jpg')) {
      contentType = 'image/jpeg';
    } // add more content types as needed

    serveStaticFile(res, path, contentType);
    return;
  }
  //route for loading in index
  if (req.method === 'GET' && reqUrl.pathname === '/') {
    fs.readFile('index.html', (err, data) => {
      if (err) {
        res.writeHead(500);
        return res.end('Error loading index.html');
      }
      res.writeHead(200, {'Content-Type': 'text/html'});
      res.end(data);
    });
  }
  //Route to make a post
  if (req.method === 'POST' && req.url === '/submitPost') {
    let body = '';
    req.on('data', chunk => {
        body += chunk.toString();
    });

    req.on('end', async () => {
        try {
          const { albumtitle, albumartist, reviewtext, albumpicture, reviewrating, reviewusername } = JSON.parse(body);
          console.log("Received username on server:", reviewusername);
          await pool.query(
            'INSERT INTO postfeed (albumtitle, albumartist, reviewtext, albumpicture, reviewrating, reviewusername) VALUES ($1, $2, $3, decode($4, \'base64\'), $5, $6)',
            [albumtitle, albumartist, reviewtext, albumpicture, reviewrating, reviewusername]
            );
            console.log("albumpicture data:", albumpicture);
            res.writeHead(200, {'Content-Type': 'application/json'});
            res.end(JSON.stringify({ message: 'Review added successfully' }));
        } catch (error) {
            res.writeHead(500);
            res.end(JSON.stringify(error));
        }
    });
  }
  // Route to search data in the database
  if (reqUrl.pathname === '/search' && req.method === 'GET') {
    const searchTerm = reqUrl.query.query; // get the search term from query parameter
    try {
      const result = await pool.query(
        'SELECT albumtitle, albumartist, encode(albumpicture, \'base64\') as albumpicturebase64 FROM albums WHERE albumtitle ILIKE $1',
        [`%${searchTerm}%`]
      );
      res.writeHead(200, {'Content-Type': 'application/json'});
      res.end(JSON.stringify(result.rows));
    } catch (error) {
      res.writeHead(500);
      res.end(JSON.stringify(error));
    }
  }
  //Route to search through users
  if (reqUrl.pathname === '/searchUsernames' && req.method === 'GET') {
    console.log("Searching for usernames with query:", reqUrl.query.query);
    const searchTerm = reqUrl.query.query; // get the search term from query parameter
    try {
      const result = await pool.query(
        'SELECT username FROM profiles WHERE username ILIKE $1',
        [`%${searchTerm}%`]
      );
      res.writeHead(200, {'Content-Type': 'application/json'});
      res.end(JSON.stringify(result.rows));
    } catch (error) {
      res.writeHead(500);
      res.end(JSON.stringify({ message: 'Error searching for usernames' }));
    }
  }
  // Route to get data from the database
  if (reqUrl.pathname === '/data' && req.method === 'GET') {
    try {
      const data = await pool.query('SELECT * FROM newtable'); // Replace 'your_table' with your table name
      res.writeHead(200, {'Content-Type': 'application/json'});
      res.end(JSON.stringify(data.rows));
    } catch (error) {
      res.writeHead(500);
      res.end(JSON.stringify(error));
    }
  }
  // Route to fetch favorite albums
  if (req.method === 'GET' && reqUrl.pathname === '/fetchFavAlbums') {
    const username = reqUrl.query.username; // Get username from query parameter
    try {
        const data = await pool.query(
            'SELECT albumtitle, albumartist, encode(albumpicture, \'base64\') as albumpicturebase64, reviewrating FROM profile_favalbums WHERE username = $1',
            [username]
        );
        res.writeHead(200, {'Content-Type': 'application/json'});
        res.end(JSON.stringify(data.rows));
    } catch (error) {
        res.writeHead(500);
        res.end(JSON.stringify(error));
    }
  }
  // Endpoint to follow a user
  if (req.method === 'POST' && req.url === '/followUser') {
    let body = '';
    req.on('data', chunk => {
        body += chunk.toString();
    });
    req.on('end', async () => {
        const { follower_username, following_username } = JSON.parse(body);
        try {
            await pool.query(
                'INSERT INTO user_relationships (follower_username, following_username) VALUES ($1, $2) ON CONFLICT DO NOTHING',
                [follower_username, following_username]
            );
            res.writeHead(200, {'Content-Type': 'application/json'});
            res.end(JSON.stringify({ message: 'Followed successfully' }));
        } catch (error) {
            console.error('Error following user:', error);
            res.writeHead(500);
            res.end(JSON.stringify({ message: 'Failed to follow user' }));
        }
    });
  }
  // Endpoint to check if the user is already following another user
  if (req.method === 'GET' && reqUrl.pathname === '/isFollowing') {
    const follower_username = reqUrl.query.follower_username;
    const following_username = reqUrl.query.following_username;

    try {
        const result = await pool.query(
            'SELECT 1 FROM user_relationships WHERE follower_username = $1 AND following_username = $2',
            [follower_username, following_username]
        );
        if (result.rows.length > 0) {
            res.writeHead(200, {'Content-Type': 'application/json'});
            res.end(JSON.stringify({ isFollowing: true }));
        } else {
            res.writeHead(200, {'Content-Type': 'application/json'});
            res.end(JSON.stringify({ isFollowing: false }));
        }
    } catch (error) {
        console.error('Error checking following status:', error);
        res.writeHead(500);
        res.end(JSON.stringify({ message: 'Failed to check following status' }));
    }
  }
  //check getProfilePicture route
  if (reqUrl.pathname === '/getProfilePicture' && req.method === 'GET') {
      const { username } = reqUrl.query;

      // Use async/await for cleaner and more readable asynchronous code
      try {
          const result = await pool.query('SELECT profile_picture FROM profiles WHERE username = $1', [username]);

          if (result.rows.length > 0) {
              if (result.rows[0].profile_picture) {
                  // Ensure the profile picture exists before trying to convert it
                  const profilePictureBase64 = result.rows[0].profile_picture.toString('base64');
                  res.writeHead(200, {'Content-Type': 'application/json'});
                  res.end(JSON.stringify({ image: profilePictureBase64 }));
              } else {
                  // Handle case where profile_picture is null
                  res.writeHead(404, {'Content-Type': 'application/json'});
                  res.end(JSON.stringify({ message: 'No profile picture available for this user' }));
              }
          } else {
              // User not found
              res.writeHead(404, {'Content-Type': 'application/json'});
              res.end(JSON.stringify({ message: 'User not found' }));
          }
      } catch (error) {
          // Catch and log database or other errors
          console.error('Database query error', error.stack);
          res.writeHead(500, {'Content-Type': 'application/json'});
          res.end(JSON.stringify({ message: 'Error fetching profile picture from database' }));
      }
  }
  // Endpoint to get profile information
  if (reqUrl.pathname === '/getProfile' && req.method === 'GET') {
    const username = reqUrl.query.username;
    try {
        const result = await pool.query('SELECT fullname, profile_picture FROM profiles WHERE username = $1', [username]);
        if (result.rows.length > 0) {
            const fullname = result.rows[0].fullname;
            let profilePictureBase64 = result.rows[0].profile_picture;
            profilePictureBase64 = profilePictureBase64 ? profilePictureBase64.toString('base64') : null;
  
            res.writeHead(200, {'Content-Type': 'application/json'});
            res.end(JSON.stringify({ fullname, profilePicture: profilePictureBase64 }));
        } else {
            res.writeHead(404, {'Content-Type': 'application/json'});
            res.end(JSON.stringify({ message: 'User not found' }));
        }
    } catch (error) {
        console.error('Error fetching profile:', error);
        res.writeHead(500);
        res.end(JSON.stringify({ message: 'Failed to fetch profile' }));
    }
  }
  // Endpoint to fetch the list of users the current user is following
  if (req.method === 'GET' && reqUrl.pathname === '/fetchFollowing') {
    const username = reqUrl.query.username; // Assuming you're passing the username as a query parameter

    try {
        const result = await pool.query(
            'SELECT following_username FROM user_relationships WHERE follower_username = $1',
            [username]
        );
        const followingUsernames = result.rows.map(row => row.following_username);
        res.writeHead(200, {'Content-Type': 'application/json'});
        res.end(JSON.stringify(followingUsernames));
    } catch (error) {
        console.error('Error fetching following list:', error);
        res.writeHead(500);
        res.end(JSON.stringify({ message: 'Failed to fetch following list' }));
    }
  }
  // Endpoint to fetch the list of users who are following the current user
  if (req.method === 'GET' && reqUrl.pathname === '/fetchFollowers') {
    const username = reqUrl.query.username; // Assuming you're passing the username as a query parameter

    try {
        const result = await pool.query(
            'SELECT follower_username FROM user_relationships WHERE following_username = $1',
            [username]
        );
        const followerUsernames = result.rows.map(row => row.follower_username);
        res.writeHead(200, {'Content-Type': 'application/json'});
        res.end(JSON.stringify(followerUsernames));
    } catch (error) {
        console.error('Error fetching followers list:', error);
        res.writeHead(500);
        res.end(JSON.stringify({ message: 'Failed to fetch followers list' }));
    }
  }
  //remove from album showcase
  if (req.method === 'POST' && req.url === '/removeFromFavAlbums') {
      let body = '';
      req.on('data', chunk => {
          body += chunk.toString();
      });
      req.on('end', async () => {
          try {
              const { username, albumtitle } = JSON.parse(body);

              await pool.query(
                  'DELETE FROM profile_favalbums WHERE username = $1 AND albumtitle = $2',
                  [username, albumtitle]
              );

              res.writeHead(200, {'Content-Type': 'application/json'});
              res.end(JSON.stringify({ message: 'Album removed from favorites successfully' }));
          } catch (error) {
              res.writeHead(500);
              res.end(JSON.stringify(error));
          }
      });
  }
  //Adding to album showcase
  if (req.method === 'POST' && req.url === '/addToFavAlbums') {
      let body = '';
      req.on('data', chunk => {
          body += chunk.toString();
      });
      req.on('end', async () => {
          try {
              const { username, albumtitle, albumartist, albumpicture, reviewrating } = JSON.parse(body);

              await pool.query(
                  'INSERT INTO profile_favalbums (username, albumtitle, albumartist, albumpicture, reviewrating) VALUES ($1, $2, $3, decode($4, \'base64\'), $5)',
                  [username, albumtitle, albumartist, albumpicture, reviewrating]
              );

              res.writeHead(200, {'Content-Type': 'application/json'});
              res.end(JSON.stringify({ message: 'Album added to favorites successfully' }));
          } catch (error) {
              res.writeHead(500);
              res.end(JSON.stringify(error));
          }
      });
  }
  //adding a profile picture to an account
  if (req.method === 'POST' && req.url === '/uploadProfilePicture') {
      let body = '';
      req.on('data', chunk => {
          body += chunk.toString();
      });
      req.on('end', async () => {
        console.log("Received request to update profile picture");
          try {
              const { username, image } = JSON.parse(body);
              // Convert the base64-encoded image to a Buffer
              const imageBuffer = Buffer.from(image, 'base64');

              // Update the user's profile picture in the database
              const query = 'UPDATE profiles SET profile_picture = $1 WHERE username = $2';
              await pool.query(query, [imageBuffer, username]);

              res.writeHead(200, {'Content-Type': 'application/json'});
              res.end(JSON.stringify({ message: 'Profile picture updated successfully' }));
          } catch (error) {
              console.error('Failed to update profile picture:', error);
              res.writeHead(500);
              res.end(JSON.stringify({ message: 'Failed to update profile picture' }));
          }
      });
  }
  // Route to add data to the database
  if (reqUrl.pathname === '/add' && req.method === 'POST') {
    let body = '';

    req.on('data', chunk => {
      body += chunk.toString();
    });

    req.on('end', async () => {
      const postData = queryString.parse(body);
      console.log("albumpicture data:", postData.albumpicture);
      try {
        await pool.query('INSERT INTO albums (somevalue) VALUES ($1)', [postData.newEntry]); // Replace 'column_name' and 'your_table'
        res.writeHead(200);
        res.end('Data added successfully');
      } catch (error) {
        res.writeHead(500);
        res.end(JSON.stringify(error));
      }
    });
  } 
  //fetch feed with given parameters
  if (req.method === 'GET' && reqUrl.pathname === '/fetchFeed') {
      const username = reqUrl.query.username; // Retrieve the username from the query parameter
      try {
          const data = await pool.query(`
              SELECT pf.albumtitle, pf.albumartist, encode(pf.albumpicture, 'base64') as albumpicturebase64, pf.reviewtext, pf.reviewrating, pf.reviewusername 
              FROM postfeed pf
              INNER JOIN user_relationships ur ON pf.reviewusername = ur.following_username
              WHERE ur.follower_username = $1`, [username]);
          res.writeHead(200, {'Content-Type': 'application/json'});
          res.end(JSON.stringify(data.rows));
      } catch (error) {
          res.writeHead(500);
          res.end(JSON.stringify(error));
      }
  }
});

const port = 3000;
server.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
